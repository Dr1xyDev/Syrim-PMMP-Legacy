<?php

/*
 *
 *  _____            _               _____           
 * / ____|          (_)             |  __ \          
 *| |  __  ___ _ __  _ ___ _   _ ___| |__) | __ ___  
 *| | |_ |/ _ \ '_ \| / __| | | / __|  ___/ '__/ _ \ 
 *| |__| |  __/ | | | \__ \ |_| \__ \ |   | | | (_) |
 * \_____|\___|_| |_|_|___/\__, |___/_|   |_|  \___/ 
 *                         __/ |                    
 *                        |___/                     
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * @author GenisysPro
 * @link https://github.com/GenisysPro/GenisysPro
 *
 *
*/

/* Syrim: 骑马 (horse riding) no implementado en v1.0.5.
 * El protocolo v113 soporta SetEntityLinkPacket para mounting, pero la
 * mecánica completa de tame+ride+inventory del horse requiere implementación
 * dedicada. Pendiente para próxima versión. */

namespace pocketmine\entity;

use pocketmine\Player;
use pocketmine\network\mcpe\protocol\AddEntityPacket;
use pocketmine\network\mcpe\protocol\MobArmorEquipmentPacket;
use pocketmine\item\Item as ItemItem;

class Horse extends Living {

        const NETWORK_ID = 23;

        /**
         * @return string
         */
        public function getName() : string{
                return "Horse";
        }

        /**
         * @param $id
         */
        public function setChestPlate($id){
                /*      
                416, 417, 418, 419 only
                */
                $pk = new MobArmorEquipmentPacket();
                $pk->eid = $this->getId();
                $pk->slots = [
                        ItemItem::get(0, 0),
                        ItemItem::get($id, 0),
                        ItemItem::get(0, 0),
                        ItemItem::get(0, 0)
                ];
                foreach($this->level->getPlayers() as $player){
                        $player->dataPacket($pk);
                }
        }

        /**
         * @param Player $player
         */
        public function spawnTo(Player $player){
                $pk = new AddEntityPacket();
                $pk->eid = $this->getId();
                $pk->type = self::NETWORK_ID;
                $pk->x = $this->x;
                $pk->y = $this->y;
                $pk->z = $this->z;
                $pk->speedX = $this->motionX;
                $pk->speedY = $this->motionY;
                $pk->speedZ = $this->motionZ;
                $pk->yaw = $this->yaw;
                $pk->pitch = $this->pitch;
                $pk->metadata = $this->dataProperties;
                $player->dataPacket($pk);

                parent::spawnTo($player);
        }

}
