<?php

/*
 *
 *  _____   _____   __   _   _   _____  __    __  _____
 * /  ___| | ____| |  \ | | | | /  ___/ \ \  / / /  ___/
 * | |     | |__   |   \| | | | | |___   \ \/ /  | |___
 * | |  _  |  __|  | |\   | | | \___  \   \  /   \___  \
 * | |_| | | |___  | | \  | | |  ___| |   / /     ___| |
 * \_____/ |_____| |_|  \_| |_| /_____/  /_/     /_____/
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * @author iTX Technologies
 * @link https://itxtech.org
 *
 */

namespace pocketmine\block;

use pocketmine\item\Item;
use pocketmine\item\Tool;
use pocketmine\nbt\NBT;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\nbt\tag\IntTag;
use pocketmine\nbt\tag\ListTag;
use pocketmine\nbt\tag\StringTag;
use pocketmine\Player;
use pocketmine\tile\Hopper as TileHopper;
use pocketmine\tile\Tile;

class Hopper extends Transparent {

        protected $id = self::HOPPER_BLOCK;

        /**
         * Hopper constructor.
         *
         * @param int $meta
         */
        public function __construct($meta = 0){
                $this->meta = $meta;
        }

        /**
         * @return int
         */
        public function getToolType(){
                return Tool::TYPE_PICKAXE;
        }

        /**
         * @return string
         */
        public function getName() : string{
                return "Hopper";
        }

        /**
         * @return int
         */
        public function getHardness(){
                return 3;
        }

        /**
         * @param Item        $item
         * @param Player|null $player
         *
         * @return bool
         */
        public function onActivate(Item $item, Player $player = null){
                if($player instanceof Player){
                        $t = $this->getLevel()->getTile($this);
                        if($t instanceof TileHopper){
                                if($t->hasLock() and !$t->checkLock($item->getCustomName())){
                                        $player->getServer()->getLogger()->debug($player->getName() . " attempted to open a locked hopper");
                                        return true;
                                }

                                if($player->isCreative() and $player->getServer()->limitedCreative){
                                        return true;
                                }
                                $player->addWindow($t->getInventory());
                        }
                }
                return true;
        }

        /**
         *
         */
        public function activate(){
                // Syrim: el "freezing" de contenido del hopper cuando recibe
                // señal de redstone requiere un sistema de redstone completo
                // con tracking de corriente por bloque. El redstone de Syrim
                // v1.0.5 todavía no soporta apagado selectivo de hoppers.
                // TODO aún pendiente: falta info oficial de Mojang sobre el
                // comportamiento exacto de freezing en MCPE v113.
        }

        /**
         * @param Item        $item
         * @param Block       $block
         * @param Block       $target
         * @param int         $face
         * @param float       $fx
         * @param float       $fy
         * @param float       $fz
         * @param Player|null $player
         *
         * @return bool
         */
        public function place(Item $item, Block $block, Block $target, $face, $fx, $fy, $fz, Player $player = null){
                $faces = [
                        0 => 0,
                        1 => 0,
                        2 => 3,
                        3 => 2,
                        4 => 5,
                        5 => 4
                ];
                $this->meta = $faces[$face];
                $this->getLevel()->setBlock($block, $this, true, true);

                $nbt = new CompoundTag("", [
                        new ListTag("Items", []),
                        new StringTag("id", Tile::HOPPER),
                        new IntTag("x", $this->x),
                        new IntTag("y", $this->y),
                        new IntTag("z", $this->z)
                ]);
                $nbt->Items->setTagType(NBT::TAG_Compound);

                if($item->hasCustomName()){
                        $nbt->CustomName = new StringTag("CustomName", $item->getCustomName());
                }

                if($item->hasCustomBlockData()){
                        foreach($item->getCustomBlockData() as $key => $v){
                                $nbt->{$key} = $v;
                        }
                }

                Tile::createTile(Tile::HOPPER, $this->getLevel(), $nbt);

                return true;
        }

        /**
         * @param Item $item
         *
         * @return array
         */
        public function getDrops(Item $item) : array{
                if($item->isPickaxe() >= 1){
                        return [
                                [Item::HOPPER, 0, 1],
                        ];
                }else{
                        return [];
                }
        }
}
