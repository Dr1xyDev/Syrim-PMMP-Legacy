<?php

/*
 *
 *  _____   _____   __   _   _   _____  __    __  _____
 * /  ___| | ____| |  \ | | | | /  ___/ \ \  / / /  ___/
 * | |     | |__   |   \| | | | | |___   \ \/ /  | |___
 * | |  _  |  __|  | |\   | | | \___  \   \  /   \___  \
 * | |_| | | |___  | | \  | | |  ___| |   / /     ___| |
 * \_____/ |_____| |_|  \_| |_| /_____/  /_/     /_____/
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * @author iTX Technologies
 * @link https://itxtech.org
 *
 */

namespace pocketmine\block;

use pocketmine\item\Item;
use pocketmine\item\Tool;
use pocketmine\math\Vector3;
use pocketmine\nbt\NBT;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\nbt\tag\IntTag;
use pocketmine\nbt\tag\ListTag;
use pocketmine\nbt\tag\StringTag;
use pocketmine\Player;
use pocketmine\tile\BrewingStand as TileBrewingStand;
use pocketmine\tile\Tile;

class BrewingStand extends Transparent {

        protected $id = self::BREWING_STAND_BLOCK;

        /**
         * BrewingStand constructor.
         *
         * @param int $meta
         */
        public function __construct($meta = 0){
                $this->meta = $meta;
        }

        /**
         * @param Item        $item
         * @param Block       $block
         * @param Block       $target
         * @param int         $face
         * @param float       $fx
         * @param float       $fy
         * @param float       $fz
         * @param Player|null $player
         *
         * @return bool
         */
        public function place(Item $item, Block $block, Block $target, $face, $fx, $fy, $fz, Player $player = null){
                if($block->getSide(Vector3::SIDE_DOWN)->isTransparent() === false){
                        $this->getLevel()->setBlock($block, $this, true, true);
                        $nbt = new CompoundTag("", [
                                new ListTag("Items", []),
                                new StringTag("id", Tile::BREWING_STAND),
                                new IntTag("x", $this->x),
                                new IntTag("y", $this->y),
                                new IntTag("z", $this->z)
                        ]);
                        $nbt->Items->setTagType(NBT::TAG_Compound);
                        if($item->hasCustomName()){
                                $nbt->CustomName = new StringTag("CustomName", $item->getCustomName());
                        }

                        if($item->hasCustomBlockData()){
                                foreach($item->getCustomBlockData() as $key => $v){
                                        $nbt->{$key} = $v;
                                }
                        }

                        Tile::createTile(Tile::BREWING_STAND, $this->getLevel(), $nbt);

                        return true;
                }
                return false;
        }

        /**
         * @return float
         */
        public function getHardness(){
                return 0.5;
        }

        /**
         * @return float
         */
        public function getResistance(){
                return 2.5;
        }

        /**
         * @return int
         */
        public function getLightLevel(){
                return 1;
        }

        /**
         * @return string
         */
        public function getName() : string{
                return "Brewing Stand";
        }

        /**
         * @param Item        $item
         * @param Player|null $player
         *
         * @return bool
         */
        public function onActivate(Item $item, Player $player = null){
                if($player instanceof Player){
                        // Syrim: el bloqueo (lock) del brewing stand para el jugador
                        // que lo abrió no se implementa en v1.0.5 - el protocolo v113
                        // no envía un ContainerClose broadcast a otros espectadores,
                        // así que un lock real requeriría un sistema de "viewer set"
                        // por tile, pendiente para versiones futuras.
                        if($player->isCreative() and $player->getServer()->limitedCreative){
                                return true;
                        }
                        $t = $this->getLevel()->getTile($this);
                        //$brewingStand = false;
                        if($t instanceof TileBrewingStand){
                                $brewingStand = $t;
                        }else{
                                $nbt = new CompoundTag("", [
                                        new ListTag("Items", []),
                                        new StringTag("id", Tile::BREWING_STAND),
                                        new IntTag("x", $this->x),
                                        new IntTag("y", $this->y),
                                        new IntTag("z", $this->z)
                                ]);
                                $nbt->Items->setTagType(NBT::TAG_Compound);
                                $brewingStand = Tile::createTile(Tile::BREWING_STAND, $this->getLevel(), $nbt);
                        }
                        $player->addWindow($brewingStand->getInventory());
                }
                return true;
        }

        /**
         * @param Item $item
         *
         * @return array
         */
        public function getDrops(Item $item) : array{
                $drops = [];
                if($item->isPickaxe() >= Tool::TIER_WOODEN){
                        $drops[] = [Item::BREWING_STAND, 0, 1];
                }
                return $drops;
        }
}
