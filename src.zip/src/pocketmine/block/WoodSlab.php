<?php

/*
 *
 *  ____            _        _   __  __ _                  __  __ ____  
 * |  _ \ ___   ___| | _____| |_|  \/  (_)_ __   ___      |  \/  |  _ \ 
 * | |_) / _ \ / __| |/ / _ \ __| |\/| | | '_ \ / _ \_____| |\/| | |_) |
 * |  __/ (_) | (__|   <  __/ |_| |  | | | | | |  __/_____| |  | |  __/ 
 * |_|   \___/ \___|_|\_\___|\__|_|  |_|_|_| |_|\___|     |_|  |_|_| 
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * @author PocketMine Team
 * @link http://www.pocketmine.net/
 * 
 *
*/

namespace pocketmine\block;

use pocketmine\item\Item;
use pocketmine\item\Tool;
use pocketmine\math\AxisAlignedBB;
use pocketmine\math\Vector3;
use pocketmine\Player;

class WoodSlab extends Transparent{

        protected $id = self::WOOD_SLAB;

        /**
         * WoodSlab constructor.
         *
         * @param int $meta
         */
        public function __construct($meta = 0){
                $this->meta = $meta;
        }

        /**
         * @return int
         */
        public function getHardness(){
                return 2;
        }

        /**
         * @return string
         */
        public function getName() : string{
                static $names = [
                        0 => "Oak",
                        1 => "Spruce",
                        2 => "Birch",
                        3 => "Jungle",
                        4 => "Acacia",
                        5 => "Dark Oak"
                ];
                return (($this->meta & 0x08) === 0x08 ? "Upper " : "") . ($names[$this->meta & 0x07] ?? "") . " Wooden Slab";
        }

        public function getVariantBitmask() : int{
                return 0x07;
        }

        /**
         * @return AxisAlignedBB
         */
        protected function recalculateBoundingBox(){

                if(($this->meta & 0x08) > 0){
                        return new AxisAlignedBB(
                                $this->x,
                                $this->y + 0.5,
                                $this->z,
                                $this->x + 1,
                                $this->y + 1,
                                $this->z + 1
                        );
                }else{
                        return new AxisAlignedBB(
                                $this->x,
                                $this->y,
                                $this->z,
                                $this->x + 1,
                                $this->y + 0.5,
                                $this->z + 1
                        );
                }
        }

        public function canBePlacedAt(Block $blockReplace, Vector3 $clickVector, int $face, bool $isClickedBlock) : bool{
                if(parent::canBePlacedAt($blockReplace, $clickVector, $face, $isClickedBlock)){
                        return true;
                }

                if($blockReplace->getId() === $this->getId() and $blockReplace->getVariant() === $this->getVariant()){
                        if(($blockReplace->getDamage() & 0x08) !== 0){ //Trying to combine with top slab
                                return $clickVector->y <= 0.5 or (!$isClickedBlock and $face === Vector3::SIDE_UP);
                        }else{
                                return $clickVector->y >= 0.5 or (!$isClickedBlock and $face === Vector3::SIDE_DOWN);
                        }
                }

                return false;
        }


        /**
         * @param Item        $item
         * @param Block       $block
         * @param Block       $target
         * @param int         $face
         * @param float       $fx
         * @param float       $fy
         * @param float       $fz
         * @param Player|null $player
         *
         * @return bool
         */
        public function place(Item $item, Block $block, Block $target, $face, $fx, $fy, $fz, Player $player = null){
                $this->meta &= 0x07;
                if($face === 0){
                        if($target->getId() === self::WOOD_SLAB and ($target->getDamage() & 0x08) === 0x08 and ($target->getDamage() & 0x07) === ($this->meta & 0x07)){
                                $this->getLevel()->setBlock($target, Block::get(Item::DOUBLE_WOOD_SLAB, $this->meta), true);

                                return true;
                        }elseif($block->getId() === self::WOOD_SLAB and ($block->getDamage() & 0x07) === ($this->meta & 0x07)){
                                $this->getLevel()->setBlock($block, Block::get(Item::DOUBLE_WOOD_SLAB, $this->meta), true);

                                return true;
                        }else{
                                $this->meta |= 0x08;
                        }
                }elseif($face === 1){
                        if($target->getId() === self::WOOD_SLAB and ($target->getDamage() & 0x08) === 0 and ($target->getDamage() & 0x07) === ($this->meta & 0x07)){
                                $this->getLevel()->setBlock($target, Block::get(Item::DOUBLE_WOOD_SLAB, $this->meta), true);

                                return true;
                        }elseif($block->getId() === self::WOOD_SLAB and ($block->getDamage() & 0x07) === ($this->meta & 0x07)){
                                $this->getLevel()->setBlock($block, Block::get(Item::DOUBLE_WOOD_SLAB, $this->meta), true);

                                return true;
                        }
                }else{
                        // Syrim: el check de colisión contra el jugador se omite
                        // por la misma razón que en RedSandstoneSlab - el cliente
                        // v113 valida antes de placement.
                        if($block->getId() === self::WOOD_SLAB){
                                if(($block->getDamage() & 0x07) === ($this->meta & 0x07)){
                                        $this->getLevel()->setBlock($block, Block::get(Item::DOUBLE_WOOD_SLAB, $this->meta), true);

                                        return true;
                                }

                                return false;
                        }else{
                                if($fy > 0.5){
                                        $this->meta |= 0x08;
                                }
                        }
                }

                if($block->getId() === self::WOOD_SLAB and ($target->getDamage() & 0x07) !== ($this->meta & 0x07)){
                        return false;
                }
                $this->getLevel()->setBlock($block, $this, true, true);

                return true;
        }

        /**
         * @return int
         */
        public function getToolType(){
                return Tool::TYPE_AXE;
        }

        /**
         * @param Item $item
         *
         * @return array
         */
        public function getDrops(Item $item) : array{
                return [
                        [$this->id, $this->meta & 0x07, 1],
                ];
        }
}